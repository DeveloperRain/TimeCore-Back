from fastapi import APIRouter, HTTPException
from app.services.zk_service import ZKService
from app.services.db_service import DBService
from app.exceptions import (
    DeviceClockDriftError,
    DeviceDisconnectedDuringSyncError,
    SyncError,
    TimeCoreError,
)
from app.utils.response import success
from app.config.logger import get_logger, log_exception
from datetime import datetime

logger = get_logger("routes.sync")

router = APIRouter(
    prefix="/sync",
    tags=["Sincronización"]
)


def sync_registered_device(device, fail_fast: bool = False):
    """
    Sincroniza los usuarios y las asistencias de un dispositivo registrado.

    :param device: Dispositivo biométrico registrado que se debe sincronizar.
    :type device: object
    :param fail_fast: Indica si la sincronización debe detenerse inmediatamente ante una desconexión.
    :type fail_fast: bool
    :return: Resumen de los usuarios, asistencias y estado del reloj procesados.
    :rtype: dict
    :raises DeviceClockDriftError: Si la fecha u hora del dispositivo presenta un desfase no permitido.
    :raises DeviceDisconnectedDuringSyncError: Si el dispositivo pierde la conexión durante la sincronización.
    :raises TimeCoreError: Si ocurre un error controlado durante la sincronización.
    """
    disconnect_notified = False

    def mark_disconnected(details=None):
        """
        Registra la desconexión del dispositivo durante la sincronización.

        :param details: Detalles opcionales relacionados con la desconexión.
        :type details: dict or None
        :return: No devuelve ningún valor.
        :rtype: None
        """
        nonlocal disconnect_notified
        if disconnect_notified:
            return
        disconnect_notified = True
        ZKService.mark_device_disconnected(
            device.ip,
            device.port,
            reason=(details or {}).get("reason")
            if isinstance(details, dict)
            else None,
        )
        DBService.update_device_status(
            device_id=device.id,
            estado="Desconectado",
        )
        DBService.create_log(
            accion="Reloj desconectado durante sincronización",
            detalle=(
                f"La sincronización de {device.name} ({device.ip}) fue cancelada "
                f"porque se perdió la comunicación. Detalles: {details or {}}"
            ),
        )

    snapshot = ZKService.get_sync_snapshot(
        ip=device.ip,
        port=device.port,
        password=getattr(device, "password", ""),
        on_disconnect=mark_disconnected,
        fail_fast=fail_fast,
    )

    usuarios = snapshot["users"]
    asistencias = snapshot["attendance"]
    clock_status = snapshot.get("clock")

    users_count = 0
    present_uids = []

    for user in usuarios:
        present_uids.append(int(user["uid"]))
        DBService.save_user(
            uid=user["uid"],
            user_id=user["user_id"],
            name=user["name"],
            role=user["role"],
            branch_id=device.branch_id,
            device_id=device.id,
            sucursal=getattr(device, "location", None),
            empresa=getattr(device, "empresa", None),
        )
        users_count += 1

    # Los empleados borrados del reloj no se eliminan de PostgreSQL:
    # se conservan como inactivos junto con todas sus asistencias.
    missing_users = DBService.mark_missing_device_users(
        device_id=device.id,
        present_uids=present_uids,
    )

    attendance_obtained = len(asistencias)
    attendance_count = DBService.save_bulk_attendance(
        asistencias,
        branch_id=device.branch_id,
        device_id=device.id,
    )

    latest_attendance = sorted(
        asistencias,
        key=lambda item: item.get("timestamp"),
    )[-5:]

    logger.info(
        "Sincronización %s (device_id=%s): obtenidas=%s, nuevas=%s, últimas=%s",
        device.name,
        device.id,
        attendance_obtained,
        attendance_count,
        latest_attendance,
    )

    ZKService.mark_device_connected(device.ip, device.port)
    DBService.update_device_sync_status(
        device_id=device.id,
        estado="Conectado",
        synced_at=datetime.utcnow(),
    )

    DBService.create_log(
        accion="Sincronización de reloj",
        detalle=(
            f"Se sincronizó {device.name} ({device.ip}). "
            f"Usuarios: {users_count}, asistencias obtenidas: {attendance_obtained}, "
            f"asistencias nuevas: {attendance_count}"
        ),
    )

    return {
        "device_id": device.id,
        "device_name": device.name,
        "ip": device.ip,
        "users_synced": users_count,
        "users_marked_inactive": missing_users,
        "attendance_obtained": attendance_obtained,
        "attendance_synced": attendance_count,
        "latest_attendance": latest_attendance,
        "clock_status": clock_status,
    }


@router.post("/users", summary="Sincronizar usuarios del reloj a PostgreSQL")
def sync_users():
    """
    Sincroniza los usuarios del reloj biométrico con la base de datos.

    :return: Respuesta con la cantidad de usuarios sincronizados.
    :rtype: dict
    :raises HTTPException: Si ocurre un error durante la obtención o almacenamiento de los usuarios.
    """
    try:
        usuarios = ZKService.get_all_users()

        count = 0

        for user in usuarios:
            DBService.save_user(
                uid=user["uid"],
                user_id=user["user_id"],
                name=user["name"],
                role=user["role"]
            )
            count += 1

        return success(
            data={"synced": count},
            message=f"Se sincronizaron {count} usuarios correctamente"
        )

    except Exception as e:
        log_exception(logger, e, "Error al sincronizar usuarios")
        raise HTTPException(
            status_code=500,
            detail=f"Error al sincronizar usuarios: {str(e)}"
        )


@router.post("/attendance", summary="Sincronizar asistencias del reloj a PostgreSQL")
def sync_attendance():
    """
    Sincroniza los registros de asistencia del reloj biométrico con la base de datos.

    :return: Respuesta con la cantidad de asistencias sincronizadas.
    :rtype: dict
    :raises HTTPException: Si ocurre un error durante la obtención o almacenamiento de las asistencias.
    """
    try:
        asistencias = ZKService.get_attendance_records()

        records_to_save = []

        for att in asistencias:
            att_dict = att.__dict__ if hasattr(att, "__dict__") else att
            records_to_save.append(att_dict)

        count = DBService.save_bulk_attendance(records_to_save)

        return success(
            data={"synced": count},
            message=f"Se sincronizaron {count} asistencias correctamente"
        )

    except Exception as e:
        log_exception(logger, e, "Error al sincronizar asistencias")
        raise HTTPException(
            status_code=500,
            detail=f"Error al sincronizar asistencias: {str(e)}"
        )

@router.post("/all", summary="Sincronizar usuarios y asistencias")
def sync_all():
    """
    Sincroniza los usuarios y las asistencias del reloj biométrico.

    :return: Respuesta con las cantidades de usuarios y asistencias sincronizados.
    :rtype: dict
    :raises HTTPException: Si ocurre un error durante la sincronización completa.
    """
    try:
        usuarios = ZKService.get_all_users()

        users_count = 0

        for user in usuarios:
            DBService.save_user(
                uid=user["uid"],
                user_id=user["user_id"],
                name=user["name"],
                role=user["role"]
            )
            users_count += 1

        asistencias = ZKService.get_attendance_records()

        records_to_save = []

        for att in asistencias:
            att_dict = att.__dict__ if hasattr(att, "__dict__") else att
            records_to_save.append(att_dict)

        attendance_count = DBService.save_bulk_attendance(records_to_save)

        return success(
            data={
                "users_synced": users_count,
                "attendance_synced": attendance_count
            },
            message="Sincronización completa realizada correctamente"
        )

    except Exception as e:
        log_exception(logger, e, "Error en sincronización completa")
        raise HTTPException(
            status_code=500,
            detail=f"Error en sincronización completa: {str(e)}"
        )
    
@router.post("/device/{device_id}", summary="Sincronizar reloj seleccionado por ID")
def sync_device_by_id(device_id: int, fail_fast: bool = False):
    """
    Sincroniza un dispositivo biométrico registrado mediante su identificador.

    :param device_id: Identificador del dispositivo que se debe sincronizar.
    :type device_id: int
    :param fail_fast: Indica si la sincronización debe detenerse inmediatamente ante una desconexión.
    :type fail_fast: bool
    :return: Respuesta con el resultado de la sincronización del dispositivo.
    :rtype: dict
    :raises HTTPException: Si el dispositivo no existe o se produce un error HTTP controlado.
    :raises DeviceClockDriftError: Si la fecha u hora del dispositivo presenta un desfase no permitido.
    :raises DeviceDisconnectedDuringSyncError: Si el dispositivo pierde la conexión durante la sincronización.
    :raises TimeCoreError: Si ocurre un error controlado durante la sincronización.
    :raises SyncError: Si ocurre un error no controlado al sincronizar el dispositivo.
    """
    try:
        device = DBService.get_device_by_id(device_id)

        if not device:
            raise HTTPException(status_code=404, detail="Reloj no encontrado")

        result = sync_registered_device(device, fail_fast=fail_fast)

        return success(
            data=result,
            message="Reloj sincronizado correctamente"
        )

    except DeviceClockDriftError as e:
        try:
            current_device = DBService.get_device_by_id(device_id)
            if current_device:
                ZKService.mark_device_connected(
                    current_device.ip,
                    current_device.port,
                )
            DBService.update_device_status(
                device_id=device_id,
                estado="Conectado",
            )
            DBService.create_log(
                accion="Sincronización bloqueada por hora incorrecta",
                detalle=(
                    f"No se sincronizó el reloj ID {device_id}: {e.message}. "
                    f"Detalles: {e.details}"
                ),
            )
        except Exception:
            pass

        raise

    except DeviceDisconnectedDuringSyncError as e:
        try:
            current_device = DBService.get_device_by_id(device_id)
            if current_device:
                ZKService.mark_device_disconnected(
                    current_device.ip,
                    current_device.port,
                    reason=e.message,
                )
            DBService.update_device_status(
                device_id=device_id,
                estado="Desconectado",
            )
        except Exception:
            pass
        raise

    except HTTPException:
        raise

    except TimeCoreError as e:
        try:
            current_device = DBService.get_device_by_id(device_id)
            if current_device:
                ZKService.mark_device_disconnected(
                    current_device.ip,
                    current_device.port,
                    reason=e.message,
                )
            DBService.update_device_status(
                device_id=device_id,
                estado="Desconectado",
            )
            DBService.create_log(
                accion="Error de sincronización",
                detalle=f"No se pudo sincronizar el reloj ID {device_id}: {e.message}",
            )
        except Exception:
            pass
        raise

    except Exception as e:
        try:
            current_device = DBService.get_device_by_id(device_id)
            if current_device:
                ZKService.mark_device_disconnected(
                    current_device.ip,
                    current_device.port,
                    reason=str(e),
                )
            DBService.update_device_status(
                device_id=device_id,
                estado="Desconectado",
            )
            DBService.create_log(
                accion="Error de sincronización",
                detalle=f"No se pudo sincronizar el reloj ID {device_id}: {str(e)}",
            )
        except Exception:
            pass

        log_exception(logger, e, "Error al sincronizar reloj por ID")
        raise SyncError(
            "No se pudo completar la sincronización del reloj",
            details={"device_id": device_id, "original_error": str(e)},
        ) from e


@router.post("/devices/all", summary="Sincronizar todos los relojes registrados")
def sync_all_registered_devices():
    """
    Sincroniza todos los dispositivos activos y disponibles registrados.

    :return: Respuesta con el resumen de dispositivos sincronizados, omitidos y fallidos.
    :rtype: dict
    """
    devices = DBService.get_all_devices()
    active_devices = [
        device
        for device in devices
        if getattr(device, "is_active", True)
        and str(getattr(device, "status", "")).strip().lower()
        not in ("inactivo", "desconectado")
    ]
    skipped_devices = len(devices) - len(active_devices)

    results = []
    failed = []

    for device in active_devices:
        try:
            results.append(sync_registered_device(device, fail_fast=True))
        except Exception as e:
            is_clock_drift = isinstance(e, DeviceClockDriftError)

            try:
                if is_clock_drift:
                    ZKService.mark_device_connected(device.ip, device.port)
                else:
                    ZKService.mark_device_disconnected(
                        device.ip,
                        device.port,
                        reason=str(e),
                    )
                DBService.update_device_status(
                    device_id=device.id,
                    estado="Conectado" if is_clock_drift else "Desconectado",
                )

                DBService.create_log(
                    accion=(
                        "Sincronización bloqueada por hora incorrecta"
                        if is_clock_drift
                        else "Error de sincronización"
                    ),
                    detalle=f"No se pudo sincronizar {device.name} ({device.ip}): {str(e)}",
                )
            except Exception:
                pass

            failed.append({
                "device_id": device.id,
                "device_name": device.name,
                "ip": device.ip,
                "error": str(e),
                "code": getattr(e, "code", "SYNC_ERROR"),
                "details": getattr(e, "details", None),
            })

            log_exception(logger, e, f"Error al sincronizar reloj {device.id}")

    users_total = sum(item["users_synced"] for item in results)
    attendance_total = sum(item["attendance_synced"] for item in results)

    

    return success(
        data={
            "total_devices": len(devices),
            "active_devices": len(active_devices),
            "skipped_devices": skipped_devices,
            "synced_devices": len(results),
            "failed_devices": len(failed),
            "users_synced": users_total,
            "attendance_synced": attendance_total,
            "results": results,
            "failed": failed,
        },
        message=(
            "Se sincronizaron todos los relojes disponibles"
            if not failed
            else "Sincronización finalizada con algunos relojes sin conexión"
        )
    )
   