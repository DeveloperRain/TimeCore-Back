"""Servicio de operaciones en base de datos."""
from typing import List, Dict, Optional
from datetime import datetime

from sqlalchemy.orm import Session
from sqlalchemy import and_, func, or_

from app.database.connection import SessionLocal
from app.models.user import User, UserRole
from app.models.attendance import AttendanceRecord
from app.models.device import Device
from app.models.log import Log
from app.models.branch import Branch
from app.models.payroll_incident import PayrollIncident
from app.config.logger import get_logger
from app.exceptions import DataValidationError
from app.services.validators import DataValidator

logger = get_logger("services.db")


class DBService:
    """Servicio de persistencia en PostgreSQL."""

    # =========================
    # HELPERS INTERNOS
    # =========================

    @staticmethod
    def _get_branch_by_name(db: Session, sucursal: Optional[str]) -> Optional[Branch]:
        if not sucursal:
            return None

        return (
            db.query(Branch)
            .filter(func.lower(func.trim(Branch.name)) == sucursal.strip().lower())
            .first()
        )

    @staticmethod
    def _resolve_branch_id(
        db: Session,
        branch_id: Optional[int] = None,
        sucursal: Optional[str] = None,
    ) -> Optional[int]:
        if branch_id is not None:
            branch = db.query(Branch).filter(Branch.id == branch_id).first()
            return branch.id if branch else None

        branch = DBService._get_branch_by_name(db, sucursal)
        return branch.id if branch else None

    @staticmethod
    def _resolve_user_branch_id(
        db: Session,
        uid: Optional[int],
        user_id: Optional[str],
        device_id: Optional[int] = None,
    ) -> Optional[int]:
        query = db.query(User)
        if device_id is not None:
            query = query.filter(User.device_id == device_id)

        user = None

        if uid is not None:
            user = query.filter(User.uid == uid).first()

        if not user and user_id:
            user = query.filter(User.user_id == user_id).first()

        return user.branch_id if user else None

    # =========================
    # USUARIOS
    # =========================

    @staticmethod
    def save_user(
        uid: int,
        user_id: str,
        name: str,
        role: str,
        sucursal: Optional[str] = None,
        branch_id: Optional[int] = None,
        device_id: Optional[int] = None,
        empresa: Optional[str] = None,
        db: Optional[Session] = None,
    ) -> User:
        """Guarda o actualiza un usuario en la BD."""
        DataValidator.validate_user(uid, user_id, name, role)

        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            resolved_branch_id = DBService._resolve_branch_id(
                db=db,
                branch_id=branch_id,
                sucursal=sucursal,
            )

            existing_query = db.query(User).filter(User.uid == uid)
            if device_id is not None:
                existing_query = existing_query.filter(User.device_id == device_id)
            existing_user = existing_query.first()

            # Adopta registros antiguos sin device_id durante la primera sincronización.
            if not existing_user and device_id is not None:
                legacy_user = (
                    db.query(User)
                    .filter(User.device_id.is_(None))
                    .filter(User.uid == uid)
                    .filter(User.user_id == user_id)
                    .first()
                )
                if legacy_user:
                    legacy_user.device_id = device_id
                    existing_user = legacy_user

            if existing_user:
                existing_user.user_id = user_id
                existing_user.name = name

                try:
                    existing_user.role = UserRole(role) if role else UserRole.usuario
                except ValueError:
                    raise DataValidationError(f"role inválido: {role}")

                if sucursal is not None:
                    existing_user.sucursal = sucursal

                if resolved_branch_id is not None:
                    existing_user.branch_id = resolved_branch_id

                if device_id is not None:
                    existing_user.device_id = device_id

                if empresa is not None:
                    existing_user.empresa = empresa

                existing_user.updated_at = datetime.utcnow()

                db.commit()
                db.refresh(existing_user)

                logger.info(f"Usuario UID {uid} actualizado en BD")
                return existing_user

            new_user = User(
                uid=uid,
                user_id=user_id,
                name=name,
                role=UserRole(role) if role else UserRole.usuario,
                sucursal=sucursal,
                branch_id=resolved_branch_id,
                device_id=device_id,
                empresa=empresa,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )

            db.add(new_user)
            db.commit()
            db.refresh(new_user)

            logger.info(f"Usuario UID {uid} guardado en BD")
            return new_user

        except DataValidationError:
            db.rollback()
            raise
        except ValueError as e:
            db.rollback()
            raise DataValidationError(f"Error al procesar role: {str(e)}")
        except Exception as e:
            db.rollback()
            logger.error(f"Error al guardar usuario {uid}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_all_users_from_db(db: Optional[Session] = None) -> List[User]:
        """Obtiene todos los usuarios activos de la BD."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            return (
                db.query(User)
                .filter(User.deleted_at.is_(None))
                .order_by(User.name.asc())
                .all()
            )
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_users_by_branch(branch_id: int, db: Optional[Session] = None) -> List[User]:
        """Obtiene empleados de una sucursal usando branch_id real."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            return (
                db.query(User)
                .filter(User.deleted_at.is_(None))
                .filter(User.branch_id == branch_id)
                .order_by(User.name.asc())
                .all()
            )
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_users_paginated(
        page: int = 1,
        limit: int = 50,
        branch_id: Optional[int] = None,
        search: Optional[str] = None,
        status: Optional[str] = None,
        db: Optional[Session] = None,
    ) -> Dict:
        """Obtiene empleados paginados y filtrados directamente en PostgreSQL."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            query = db.query(User).filter(User.deleted_at.is_(None))

            if branch_id is not None:
                query = query.filter(User.branch_id == branch_id)

            if status:
                query = query.filter(func.lower(User.status) == status.lower())

            if search and search.strip():
                term = f"%{search.strip()}%"
                query = query.filter(
                    or_(
                        User.name.ilike(term),
                        User.user_id.ilike(term),
                        User.area.ilike(term),
                        User.empresa.ilike(term),
                        User.email.ilike(term),
                        User.sucursal.ilike(term),
                    )
                )

            total = query.count()
            items = (
                query.order_by(User.name.asc())
                .offset((page - 1) * limit)
                .limit(limit)
                .all()
            )

            return {"items": items, "total": total}
        finally:
            if close_db:
                db.close()

    @staticmethod
    def update_user_status(uid: int, status: str, db: Optional[Session] = None) -> Optional[User]:
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            user = db.query(User).filter(User.uid == uid).first()

            if not user:
                return None

            user.status = status
            user.updated_at = datetime.utcnow()

            db.commit()
            db.refresh(user)

            return user

        except Exception as e:
            db.rollback()
            logger.error(f"Error al actualizar estado del usuario {uid}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def update_user_profile(
        uid: int,
        role: str = None,
        sucursal: str = None,
        email: str = None,
        area: str = None,
        empresa: str = None,
        branch_id: Optional[int] = None,
        db: Optional[Session] = None,
    ) -> Optional[User]:
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            user = db.query(User).filter(User.uid == uid).first()

            if not user:
                return None

            if role is not None:
                user.role = UserRole(role) if role else UserRole.usuario

            resolved_branch_id = DBService._resolve_branch_id(
                db=db,
                branch_id=branch_id,
                sucursal=sucursal,
            )

            if branch_id is not None:
                branch = db.query(Branch).filter(Branch.id == branch_id).first()

                if branch:
                    user.branch_id = branch.id
                    user.sucursal = branch.name

            elif sucursal is not None:
                user.sucursal = sucursal

                if resolved_branch_id is not None:
                    user.branch_id = resolved_branch_id

            if email is not None:
                user.email = email

            if area is not None:
                user.area = area

            if empresa is not None:
                user.empresa = empresa

            user.updated_at = datetime.utcnow()

            db.commit()
            db.refresh(user)

            return user

        except Exception as e:
            db.rollback()
            logger.error(f"Error al actualizar perfil del usuario {uid}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def delete_user(uid: int, db: Optional[Session] = None) -> bool:
        """Elimina un usuario de la BD conservando sus asistencias históricas."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            user = db.query(User).filter(User.uid == uid).first()

            if user:
                db.query(AttendanceRecord).filter(AttendanceRecord.uid == uid).update(
                    {AttendanceRecord.uid: None},
                    synchronize_session=False,
                )

                db.delete(user)
                db.commit()

                logger.info(f"Usuario UID {uid} eliminado de BD")
                return True

            return False

        except Exception as e:
            db.rollback()
            logger.error(f"Error al eliminar usuario {uid}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    # =========================
    # RELOJES / DEVICES
    # =========================

    @staticmethod
    def save_device(
        nombre: str,
        ip: str,
        puerto: int = 4370,
        password: str = "",
        sucursal: str = None,
        ubicacion: str = None,
        empresa: str = "FISMAN",
        branch_id: Optional[int] = None,
        auto_sync_enabled: bool = True,
        sync_interval_minutes: int = 4,
        db: Optional[Session] = None,
    ) -> Device:
        """Guarda un nuevo reloj biométrico en la BD."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            existing = db.query(Device).filter(Device.ip == ip).first()

            if existing:
                raise DataValidationError(f"Ya existe un reloj registrado con la IP {ip}")

            resolved_branch_id = DBService._resolve_branch_id(
                db=db,
                branch_id=branch_id,
                sucursal=sucursal,
            )

            if branch_id is not None:
                branch = db.query(Branch).filter(Branch.id == branch_id).first()
                if branch:
                    sucursal = branch.name

            device = Device(
                name=nombre,
                ip=ip,
                port=puerto,
                password=password,
                branch_id=resolved_branch_id,
                location=sucursal,
                description=ubicacion,
                empresa=empresa,
                is_active=True,
                auto_sync_enabled=bool(auto_sync_enabled),
                sync_interval_minutes=max(1, min(int(sync_interval_minutes or 4), 60)),
                status="Desconectado",
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )

            db.add(device)
            db.commit()
            db.refresh(device)

            return device

        except Exception as e:
            db.rollback()
            logger.error(f"Error al guardar reloj {ip}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_all_devices(db: Optional[Session] = None) -> List[Device]:
        """Obtiene todos los relojes registrados."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            return db.query(Device).order_by(Device.id.asc()).all()
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_devices_by_branch(branch_id: int, db: Optional[Session] = None) -> List[Device]:
        """Obtiene relojes de una sucursal usando branch_id real."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            return (
                db.query(Device)
                .filter(Device.branch_id == branch_id)
                .order_by(Device.id.asc())
                .all()
            )
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_device_by_id(device_id: int, db: Optional[Session] = None) -> Optional[Device]:
        """Obtiene un reloj por ID."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            return db.query(Device).filter(Device.id == device_id).first()
        finally:
            if close_db:
                db.close()

    @staticmethod
    def update_device(
        device_id: int,
        nombre: str = None,
        ip: str = None,
        puerto: int = None,
        password: str = None,
        sucursal: str = None,
        ubicacion: str = None,
        empresa: str = None,
        activo: bool = None,
        branch_id: Optional[int] = None,
        auto_sync_enabled: Optional[bool] = None,
        sync_interval_minutes: Optional[int] = None,
        db: Optional[Session] = None,
    ) -> Optional[Device]:
        """Actualiza datos de un reloj registrado."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            device = db.query(Device).filter(Device.id == device_id).first()

            if not device:
                return None

            if nombre is not None:
                device.name = nombre

            if ip is not None:
                device.ip = ip

            if puerto is not None:
                device.port = puerto

            if password is not None:
                if not str(password).strip():
                    raise DataValidationError("La contraseña del reloj no puede quedar vacía")
                device.password = str(password).strip()

            if branch_id is not None:
                branch = db.query(Branch).filter(Branch.id == branch_id).first()

                if branch:
                    device.branch_id = branch.id
                    device.location = branch.name

            elif sucursal is not None:
                device.location = sucursal

                resolved_branch_id = DBService._resolve_branch_id(
                    db=db,
                    sucursal=sucursal,
                )

                if resolved_branch_id is not None:
                    device.branch_id = resolved_branch_id

            if ubicacion is not None:
                device.description = ubicacion

            if empresa is not None:
                device.empresa = empresa

            if auto_sync_enabled is not None:
                device.auto_sync_enabled = bool(auto_sync_enabled)

            if sync_interval_minutes is not None:
                interval = int(sync_interval_minutes)
                if interval < 1 or interval > 60:
                    raise DataValidationError("El intervalo debe estar entre 1 y 60 minutos")
                device.sync_interval_minutes = interval

            if activo is not None:
                device.is_active = activo

                if activo and device.status == "Inactivo":
                    device.status = "Desconectado"

                if not activo:
                    device.status = "Inactivo"

            device.updated_at = datetime.utcnow()

            db.commit()
            db.refresh(device)

            return device

        except Exception as e:
            db.rollback()
            logger.error(f"Error al actualizar reloj {device_id}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def update_device_status(
        device_id: int,
        estado: str,
        ultima_sincronizacion: datetime = None,
        db: Optional[Session] = None,
    ) -> Optional[Device]:
        """Actualiza estado y última conexión de un reloj."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            device = db.query(Device).filter(Device.id == device_id).first()

            if not device:
                return None

            device.status = estado

            if ultima_sincronizacion:
                device.last_connection = ultima_sincronizacion

            device.updated_at = datetime.utcnow()

            db.commit()
            db.refresh(device)

            return device

        except Exception as e:
            db.rollback()
            logger.error(f"Error al actualizar estado del reloj {device_id}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def update_device_sync_status(
        device_id: int,
        estado: str = "Conectado",
        synced_at: datetime = None,
        db: Optional[Session] = None,
    ) -> Optional[Device]:
        """Actualiza el estado y la última sincronización real del reloj."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            device = db.query(Device).filter(Device.id == device_id).first()
            if not device:
                return None

            now = synced_at or datetime.utcnow()
            device.status = estado
            device.last_connection = now
            device.last_sync_at = now
            device.updated_at = datetime.utcnow()
            db.commit()
            db.refresh(device)
            return device
        except Exception as e:
            db.rollback()
            logger.error(f"Error al actualizar sincronización del reloj {device_id}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def delete_device(device_id: int, db: Optional[Session] = None) -> bool:
        """Inactiva un reloj registrado en lugar de eliminarlo."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            device = db.query(Device).filter(Device.id == device_id).first()

            if not device:
                return False

            device.is_active = False
            device.status = "Inactivo"
            device.updated_at = datetime.utcnow()

            db.commit()

            return True

        except Exception as e:
            db.rollback()
            logger.error(f"Error al inactivar reloj {device_id}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def activate_device(device_id: int, db: Optional[Session] = None) -> bool:
        """Reactiva un reloj previamente inactivado."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            device = db.query(Device).filter(Device.id == device_id).first()

            if not device:
                return False

            device.is_active = True
            device.status = "Desconectado"
            device.updated_at = datetime.utcnow()

            db.commit()

            return True

        except Exception as e:
            db.rollback()
            logger.error(f"Error al activar reloj {device_id}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    # =========================
    # ASISTENCIAS
    # =========================

    @staticmethod
    def save_attendance(
        uid: int,
        user_id: str,
        name: str,
        timestamp: datetime,
        status: str,
        branch_id: Optional[int] = None,
        device_id: Optional[int] = None,
        db: Optional[Session] = None,
    ) -> AttendanceRecord:
        """Guarda un registro de asistencia en la BD."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            resolved_branch_id = branch_id

            if resolved_branch_id is None:
                resolved_branch_id = DBService._resolve_user_branch_id(
                    db=db,
                    uid=uid,
                    user_id=user_id,
                    device_id=device_id,
                )

            record = AttendanceRecord(
                uid=uid,
                user_id=user_id,
                name=name,
                branch_id=resolved_branch_id,
                device_id=device_id,
                timestamp=timestamp,
                status=status,
            )

            db.add(record)
            db.commit()
            db.refresh(record)

            logger.debug(f"Registro de asistencia guardado: {user_id} - {timestamp}")
            return record

        except Exception as e:
            db.rollback()
            logger.error(f"Error al guardar asistencia {user_id}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def save_bulk_attendance(
        records: List[Dict],
        branch_id: Optional[int] = None,
        device_id: Optional[int] = None,
        db: Optional[Session] = None,
    ) -> int:
        """Guarda múltiples registros de asistencia. Evita duplicados."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            count = 0

            for record in records:
                timestamp = record.get("timestamp")

                if not timestamp:
                    logger.warning(f"timestamp faltante en registro: {record}")
                    continue

                if isinstance(timestamp, str):
                    try:
                        timestamp = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                    except ValueError:
                        logger.warning(f"Formato de timestamp inválido: {timestamp}")
                        continue

                try:
                    DataValidator.validate_attendance(
                        record.get("uid"),
                        record.get("user_id"),
                        record.get("name"),
                        timestamp,
                        record.get("status"),
                    )
                except DataValidationError as e:
                    logger.warning(f"Registro de asistencia inválido descartado: {e}")
                    continue

                uid = record.get("uid")
                user_id = record.get("user_id")
                status = record.get("status")
                record_branch_id = record.get("branch_id", branch_id)
                record_device_id = record.get("device_id", device_id)

                if record_branch_id is None:
                    record_branch_id = DBService._resolve_user_branch_id(
                        db=db,
                        uid=uid,
                        user_id=user_id,
                        device_id=record_device_id,
                    )

                existing = db.query(AttendanceRecord).filter(
                    and_(
                        AttendanceRecord.device_id == record_device_id,
                        AttendanceRecord.uid == uid,
                        AttendanceRecord.timestamp == timestamp,
                        AttendanceRecord.status == status,
                    )
                ).first()

                if not existing:
                    att = AttendanceRecord(
                        uid=uid,
                        user_id=user_id,
                        name=record.get("name"),
                        branch_id=record_branch_id,
                        device_id=record_device_id,
                        timestamp=timestamp,
                        status=status,
                    )

                    db.add(att)
                    count += 1

            db.commit()

            logger.info(f"Se guardaron {count} registros de asistencia en BD")
            return count

        except DataValidationError:
            db.rollback()
            raise
        except Exception as e:
            db.rollback()
            logger.error(f"Error al guardar asistencias en bulk: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_attendance_paginated(
        page: int = 1,
        limit: int = 50,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        branch_id: Optional[int] = None,
        user_ids: Optional[List[str]] = None,
        db: Optional[Session] = None,
    ) -> Dict:
        """Obtiene asistencias paginadas sin cargar toda la tabla en memoria."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            query = db.query(AttendanceRecord)

            if start_date is not None:
                query = query.filter(AttendanceRecord.timestamp >= start_date)
            if end_date is not None:
                query = query.filter(AttendanceRecord.timestamp <= end_date)
            if branch_id is not None:
                query = query.filter(AttendanceRecord.branch_id == branch_id)
            if user_ids:
                normalized = [str(value) for value in user_ids if str(value).strip()]
                if normalized:
                    query = query.filter(AttendanceRecord.user_id.in_(normalized))

            total = query.count()
            items = (
                query.order_by(AttendanceRecord.timestamp.desc())
                .offset((page - 1) * limit)
                .limit(limit)
                .all()
            )

            return {"items": items, "total": total}
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_attendance_by_date_range(
        start_date: datetime,
        end_date: datetime,
        db: Optional[Session] = None,
    ) -> List[AttendanceRecord]:
        """Obtiene registros de asistencia en un rango de fechas."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            return (
                db.query(AttendanceRecord)
                .filter(
                    and_(
                        AttendanceRecord.timestamp >= start_date,
                        AttendanceRecord.timestamp <= end_date,
                    )
                )
                .order_by(AttendanceRecord.timestamp.desc())
                .all()
            )
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_attendance_by_branch(
        branch_id: int,
        db: Optional[Session] = None,
    ) -> List[AttendanceRecord]:
        """Obtiene asistencias de una sucursal usando branch_id real."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            return (
                db.query(AttendanceRecord)
                .filter(AttendanceRecord.branch_id == branch_id)
                .order_by(AttendanceRecord.timestamp.desc())
                .all()
            )
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_attendance_by_user(
        user_id: str,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        db: Optional[Session] = None,
    ) -> List[AttendanceRecord]:
        """Obtiene asistencias de un usuario específico."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            query = db.query(AttendanceRecord).filter(AttendanceRecord.user_id == user_id)

            if start_date and end_date:
                query = query.filter(
                    and_(
                        AttendanceRecord.timestamp >= start_date,
                        AttendanceRecord.timestamp <= end_date,
                    )
                )

            return query.order_by(AttendanceRecord.timestamp.desc()).all()

        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_attendance_dates_summary(db: Optional[Session] = None) -> List[Dict]:
        """Obtiene las fechas con registros de asistencia y su total."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            attendance_date = func.date(AttendanceRecord.timestamp)

            rows = (
                db.query(
                    attendance_date.label("fecha"),
                    func.count(AttendanceRecord.id).label("total"),
                )
                .group_by(attendance_date)
                .order_by(attendance_date.desc())
                .all()
            )

            return [
                {
                    "fecha": row.fecha.isoformat()
                    if hasattr(row.fecha, "isoformat")
                    else str(row.fecha),
                    "total": int(row.total),
                }
                for row in rows
            ]

        finally:
            if close_db:
                db.close()


    # =========================
    # PRENÓMINA / INCIDENCIAS
    # =========================

    @staticmethod
    def get_payroll_incidents_by_range(
        start_date,
        end_date,
        branch_id: Optional[int] = None,
        db: Optional[Session] = None,
    ) -> List[PayrollIncident]:
        """Obtiene incidencias de prenómina en un rango de fechas."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            query = (
                db.query(PayrollIncident)
                .filter(
                    and_(
                        PayrollIncident.fecha >= start_date,
                        PayrollIncident.fecha <= end_date,
                    )
                )
            )

            if branch_id is not None:
                query = query.join(
                    User,
                    PayrollIncident.user_id == User.user_id,
                    isouter=True,
                ).filter(User.branch_id == branch_id)

            return query.order_by(
                PayrollIncident.fecha.asc(),
                PayrollIncident.hora.asc(),
                PayrollIncident.user_id.asc(),
            ).all()

        finally:
            if close_db:
                db.close()

    @staticmethod
    def save_payroll_incident(
        user_id: str,
        fecha,
        hora,
        incidencia: str,
        descripcion: str = None,
        db: Optional[Session] = None,
    ) -> PayrollIncident:
        """Crea o actualiza una incidencia por empleado, fecha y hora."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            clean_user_id = str(user_id).strip()
            clean_incidencia = str(incidencia or "").strip()
            clean_descripcion = str(descripcion).strip() if descripcion is not None else None

            if not clean_user_id:
                raise DataValidationError("El empleado es obligatorio")

            if not clean_incidencia:
                raise DataValidationError("La incidencia es obligatoria")

            user = db.query(User).filter(User.user_id == clean_user_id).first()

            existing = (
                db.query(PayrollIncident)
                .filter(
                    and_(
                        PayrollIncident.user_id == clean_user_id,
                        PayrollIncident.fecha == fecha,
                        PayrollIncident.hora == hora,
                    )
                )
                .first()
            )

            if existing:
                existing.uid = user.uid if user else existing.uid
                existing.incidencia = clean_incidencia
                existing.descripcion = clean_descripcion
                existing.updated_at = datetime.utcnow()

                db.commit()
                db.refresh(existing)
                return existing

            incident = PayrollIncident(
                uid=user.uid if user else None,
                user_id=clean_user_id,
                fecha=fecha,
                hora=hora,
                incidencia=clean_incidencia,
                descripcion=clean_descripcion,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )

            db.add(incident)
            db.commit()
            db.refresh(incident)

            return incident

        except Exception as e:
            db.rollback()
            logger.error(f"Error al guardar incidencia de prenómina {user_id}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def delete_payroll_incident(
        incident_id: int,
        db: Optional[Session] = None,
    ) -> bool:
        """Elimina una incidencia de prenómina."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            incident = db.query(PayrollIncident).filter(PayrollIncident.id == incident_id).first()

            if not incident:
                return False

            db.delete(incident)
            db.commit()

            return True

        except Exception as e:
            db.rollback()
            logger.error(f"Error al borrar incidencia de prenómina {incident_id}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    # =========================
    # SUCURSALES
    # =========================

    @staticmethod
    def create_branch(
        name: str,
        address: str = None,
        is_active: bool = True,
        status: str = "Activo",
        db: Optional[Session] = None,
    ) -> Branch:
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            existing = db.query(Branch).filter(
                func.lower(func.trim(Branch.name)) == name.strip().lower()
            ).first()

            if existing:
                raise DataValidationError(f"Ya existe una sucursal llamada {name}")

            if status not in ("Activo", "Inactivo"):
                status = "Activo" if is_active else "Inactivo"

            branch = Branch(
                name=name,
                address=address,
                is_active=status == "Activo",
                status=status,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )

            db.add(branch)
            db.commit()
            db.refresh(branch)

            return branch

        except Exception as e:
            db.rollback()
            logger.error(f"Error al crear sucursal {name}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_all_branches(db: Optional[Session] = None) -> List[Branch]:
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            return db.query(Branch).order_by(Branch.id.asc()).all()
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_branch_by_id(branch_id: int, db: Optional[Session] = None) -> Optional[Branch]:
        """Obtiene una sucursal por ID."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            return db.query(Branch).filter(Branch.id == branch_id).first()
        finally:
            if close_db:
                db.close()

    @staticmethod
    def update_branch(
        branch_id: int,
        name: str = None,
        address: str = None,
        is_active: bool = None,
        status: str = None,
        db: Optional[Session] = None,
    ) -> Optional[Branch]:
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            branch = db.query(Branch).filter(Branch.id == branch_id).first()

            if not branch:
                return None

            old_name = branch.name

            if name is not None:
                branch.name = name

            if address is not None:
                branch.address = address

            if status is not None:
                if status not in ("Activo", "Inactivo"):
                    status = "Activo" if is_active else "Inactivo"

                branch.status = status
                branch.is_active = status == "Activo"

            elif is_active is not None:
                branch.is_active = is_active
                branch.status = "Activo" if is_active else "Inactivo"

            branch.updated_at = datetime.utcnow()

            db.commit()
            db.refresh(branch)

            if name is not None and name != old_name:
                db.query(User).filter(User.branch_id == branch_id).update(
                    {User.sucursal: branch.name},
                    synchronize_session=False,
                )

                db.query(Device).filter(Device.branch_id == branch_id).update(
                    {Device.location: branch.name},
                    synchronize_session=False,
                )

                db.commit()

            return branch

        except Exception as e:
            db.rollback()
            logger.error(f"Error al actualizar sucursal {branch_id}: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    # =========================
    # LOGS
    # =========================

    @staticmethod
    def create_log(accion: str, detalle: str, db: Optional[Session] = None) -> Log:
        """Crea un registro de auditoría."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            log = Log(
                accion=accion,
                detalle=detalle,
                created_at=datetime.utcnow(),
            )

            db.add(log)
            db.commit()
            db.refresh(log)

            return log

        except Exception as e:
            db.rollback()
            logger.error(f"Error al crear log: {str(e)}")
            raise
        finally:
            if close_db:
                db.close()

    @staticmethod
    def get_logs(limit: int = 100, db: Optional[Session] = None) -> List[Log]:
        """Obtiene los últimos registros de auditoría."""
        if db is None:
            db = SessionLocal()
            close_db = True
        else:
            close_db = False

        try:
            return (
                db.query(Log)
                .order_by(Log.created_at.desc())
                .limit(limit)
                .all()
            )
        finally:
            if close_db:
                db.close()
